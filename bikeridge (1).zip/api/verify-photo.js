/**
 * api/verify-photo.js
 * ---------------------------------------------------------------
 * OPTIONAL real fix for "any photo works" on the pre-ride audit.
 * Client-side JS can never truly tell what's IN a photo — only an
 * AI vision call can. This endpoint sends the photo to Google
 * Gemini (free tier, no credit card) and asks a yes/no: does this
 * actually look like a bicycle?
 *
 * ENV VAR NEEDED (free — no credit card required):
 *   GEMINI_API_KEY  — from aistudio.google.com → "Get API key"
 *     1. Go to aistudio.google.com
 *     2. Sign in with any Google account
 *     3. Click "Get API key" in the left sidebar → "Create API key"
 *     4. Copy it — that's GEMINI_API_KEY in Vercel
 *
 * If this key isn't set, the endpoint responds { skipped: true }
 * and the app quietly falls back to file-type/size/duplicate checks
 * only — it will NOT break your app if you skip this step.
 *
 * POST body: { imageBase64: "<raw base64, no data: prefix>", mediaType: "image/jpeg" }
 * ---------------------------------------------------------------
 */
module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const { GEMINI_API_KEY } = process.env;
  if (!GEMINI_API_KEY) {
    return res.status(200).json({ skipped: true, reason: 'GEMINI_API_KEY not configured' });
  }

  const { imageBase64, mediaType } = req.body || {};
  if (!imageBase64 || typeof imageBase64 !== 'string') {
    return res.status(400).json({ error: 'imageBase64 required' });
  }
  // rough size guard — base64 is ~33% bigger than raw bytes, cap around 15MB raw
  if (imageBase64.length > 20 * 1024 * 1024) {
    return res.status(413).json({ error: 'Image too large' });
  }
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  const type = allowedTypes.includes(mediaType) ? mediaType : 'image/jpeg';

  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: type, data: imageBase64 } },
              { text: 'Does this photo clearly show a real bicycle (or a person with one)? Reply with exactly one word: YES or NO.' }
            ]
          }],
          generationConfig: { maxOutputTokens: 10, temperature: 0 }
        })
      }
    );
    if (!r.ok) {
      const detail = await r.text();
      return res.status(502).json({ error: 'Vision check failed', detail });
    }
    const data = await r.json();
    const answer = (data.candidates?.[0]?.content?.parts?.[0]?.text || '').trim().toUpperCase();
    return res.status(200).json({ skipped: false, isBike: answer.startsWith('YES') });
  } catch (err) {
    return res.status(500).json({ error: 'Vision check errored', detail: String(err) });
  }
};
